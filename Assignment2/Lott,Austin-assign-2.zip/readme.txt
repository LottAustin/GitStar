[Austin Lott], [A00744090], [1C], [02/03/2014]

This assignment is [95]% complete.


------------------------
Question one (TriangleArea) status:

[complete]
[Working as intended.]

------------------------
Question two (CylinderStats) status:

[complete]
[Working as intended.]

------------------------
Question three (Bookshelf) status:

[complete]
[Working as intended.]

------------------------
Question four (BoxTest) status:

[complete]
[Working as intended.]

------------------------
Question five (TrafficLight) status:

[not complete]
[Program runs as describe by the instructions. However it was done using elements 
of chapters beyond what is allowed.]
